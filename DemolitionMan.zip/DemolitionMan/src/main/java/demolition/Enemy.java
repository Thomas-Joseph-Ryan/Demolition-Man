package demolition;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

import processing.core.PApplet;
import processing.core.PImage;

public abstract class Enemy extends Character{

    private HashMap<Integer, PImage[]> enemyAnimations;
    private Point spawn;

    protected int timeBetweenMoves = 1;
    protected int timer;
    protected Random generator;

    /**
     * Enemy parent class constuctor. This class extends from the Character class.
     * This is the parent class to all Enemy objects.
     * @param level Levels object being used by the app
     * @param spawn Point object, the spawn point of the enemy.
     * @param app The PApplet App object running the game.
     * @param enemyAnimations A HashMap containing PImage[] corresponding to its direction.
     */
    public Enemy(Levels level, Point spawn, PApplet app, HashMap<Integer, PImage[]> enemyAnimations){
        super(level, app);
        this.enemyAnimations = enemyAnimations;
        this.spawn = spawn;
        this.generator = new Random();
    }

    /**
     * The tick method for enemy objects.
     */
    public void tick(){
        this.timer ++;
        collision(x, y);
        if (this.alive) {
            if (level.getNewLevel()) {
                this.x = spawn.getX();
                this.y = spawn.getY();
            }
            AnimateWalk(currentDirection, enemyAnimations);
            if (timer > timeBetweenMoves * App.FPS) {
                move();
                timer = 0;
            }
            
        }
    }
    
    /**
     * The draw method for enemy objects. Will only draw if alive.
     */
    public void draw(){
        if (this.alive)
            app.image(this.sprite, x *gridsize, (y - 1) * gridsize + offset);

    }

    /**
     * Gets the avaliable squares surrounding the Enemy which can be moved too.
     * These are all squares except for the wall and broken wall.
     * @return An ArrayList<Integer> with 0 : down, 1 : left, 2 : up, 3 : right
     */
    public ArrayList<Integer> checkSurroundings() {
        ArrayList<Integer> avaliableDirections = new ArrayList<>();
        char[][] currentleveldata = level.getLevelData();
        char down = currentleveldata[y+1][x];
        char left = currentleveldata[y][x-1];
        char up = currentleveldata[y-1][x];
        char right = currentleveldata[y][x+1];
        if (down != 'W' && down != 'B')
            avaliableDirections.add(0);
        if (left != 'W' && left != 'B')
            avaliableDirections.add(1);
        if (up != 'W' && up != 'B')
            avaliableDirections.add(2);
        if (right != 'W' && right != 'B')
            avaliableDirections.add(3);
        return avaliableDirections;
    }

    /**
     * Changes the level data to represent a move by the character.
     * @param c the char to append the level data with.
     */
    public void changePosition(char c) {
        if (this.currentDirection == 0){
            collision(x, y+1);
            level.appendLevelData(x, x, y, y+1, c);
            this.y += 1;
        } else if (this.currentDirection == 1){
            collision(x-1, y);
            level.appendLevelData(x, x-1, y, y, c);
            this.x -= 1;
        } else if (this.currentDirection == 2) {
            level.appendLevelData(x, x, y, y-1, c);
            this.y -= 1;
        } else if (this.currentDirection == 3) {
            level.appendLevelData(x, x+1, y, y, c);
            this.x += 1;
        }
    }

    /**
     * The collision method for an Enemy object
     */
    public void collision(int x, int y) {
        if (level.getLevelData()[y][x] == 'E') {
            this.alive = false;
        }
    }

    /**
     * Returns false as Enemy objects are not the bombGuy
     */
    public boolean isBombguy(){
        return false;
    }

    /**
     * Abstract method, to decide where the enemy will move next.
     * @return True if enemy has moved, false otherwise.
     */
    public abstract boolean move();
    
}
