package demolition;

import java.util.HashMap;

import processing.core.PImage;

public class AnimationHolder {

    private HashMap<Integer, PImage[]> redAnimations;
    private HashMap<Integer, PImage[]> yellowAnimations;
    private PImage[] explodingSprites;
    private PImage[] explodedSprites;

    /**
     * AnimationHolder constuctor
     */
    public AnimationHolder(){}

    /**
     * Sets the HashMap for the Red Enemy animation, This is used to save the
     * hashmap after a dummy redenemy is created in setup. This means the sprites can just be accessed
     * from this file for each Red Enemy that is made.
     * @param redAnimations the HashMap of sprites according to each direction.
     */
    public void setRedAnimations(HashMap<Integer, PImage[]> redAnimations){
        this.redAnimations = redAnimations;
    }

    /**
     * Gets the Red Enemy animation HashMap, this is used to pass these animations into
     * the new RedEnemy object
     * @return Red Enemy animation HashMap
     */
    public HashMap<Integer, PImage[]> getRedAnimations(){
        return this.redAnimations;
    }

    /**
     * Sets the HashMap for the Yellow Enemy animation, This is used to save the
     * hashmap after a dummy yellow enemy is created in setup. This means the sprites can just be accessed
     * from this file for each yellow Enemy that is made.
     * @param yellowAnimations the HashMap of sprites according to each direction.
     */
    public void setYellowAnimations(HashMap<Integer, PImage[]> yellowAnimations){
        this.yellowAnimations = yellowAnimations;
    }

    /**
     * Gets the Yellow Enemy animation HashMap, this is used to pass these animations into
     * the new YellowEnemy object
     * @return Yellow Enemy animation HashMap
     */
    public HashMap<Integer, PImage[]> getYellowAnimations(){
        return this.yellowAnimations;
    }

    /**
     * Sets the Array of PImages of the bomb before it exploades
     * @param sprites Array of PImages
     */
    public void setExploadingSprites(PImage[] sprites){
        this.explodingSprites = sprites;
    }

    /**
     * Gets the Array of PImages of the bomb exploading
     * @return Array of PImages
     */
    public PImage[] getExploadingSprites() {
        return this.explodingSprites;
    }
    
    /**
     * Sets the array of PImages of the bomb during its explosion
     * @param sprites Array of PImages
     */
    public void setExploadedSprites(PImage[] sprites){
        this.explodedSprites = sprites;
    }

    /**
     * Gets the array of PImages of the bomb during its explosion
     * @return Array of PImages
     */
    public PImage[] getExploadedSprites() {
        return this.explodedSprites;
    }
}
