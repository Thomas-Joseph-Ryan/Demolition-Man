package demolition;

public interface GameObject {

    /**
     * A draw method to display the GameObject on the screen
     */
    public void draw(); 
    /**
     * A tick method to ensure the game object logic is working.
     */
    public void tick();
    /**
     * A collision method to handle situations between different game objects
     * and tiles on the map.
     * @param x
     * @param y
     */
    public void collision(int x, int y);

}
