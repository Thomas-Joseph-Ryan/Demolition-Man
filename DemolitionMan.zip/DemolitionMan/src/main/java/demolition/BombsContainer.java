package demolition;

import java.util.ArrayList;

public class BombsContainer {
    
    private ArrayList<Bomb> bombs = new ArrayList<>();

    /**
     * BombsContainer constuctor
     */
    public BombsContainer(){
    }

    /**
     * Tick method for BombContainer object. Ticks through
     * all of the bombs currently on the map, then removes the
     * ones that no longer exist.
     */
    public void tick(){
        for ( int i = 0; i < bombs.size(); i++) {
            bombs.get(i).tick();
            if (!bombs.get(i).getExistenceState()){
                bombs.remove(i);
                i--;
            }
        }
    }

    /**
     * Draw all bombs that currently exist and what state
     * they are in.
     */
    public void draw() {
        for (Bomb b : bombs) {
            b.draw();
        }
    }

    /**
     * Adds a bomb to the container.
     * @param b Bomb object being created
     */
    public void addBomb(Bomb b) {
        bombs.add(b);
    }

    /**
     * Removes all bombs from the container, 
     * used when a level is reset or changed.
     */
    public void resetbombs() {
        for ( int i = 0; i < bombs.size(); i++) {
            bombs.remove(i);
            i--;
        }
    }

    /**
     * For testing purposes, returns the size of the
     * bombs container list.
     * @return integer size of bombs existing.
     */
    public int getBombListSize(){
        return this.bombs.size();
    }

}
