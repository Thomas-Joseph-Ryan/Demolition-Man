package demolition;

public class Point {

    private int x;
    private int y;

    /**
     * Constructor for a point object, these act like co-ordinates.
     * @param x x co-ordinate.
     * @param y y co-ordinate.
     */
    public Point(int x, int y) {
        this.x = x;
        this.y = y;

    }

    /**
     * Sets the x co-ordinate
     * @param x x co-ordinate
     */
    public void setX(int x) {
        this.x = x;
    }

    /**
     * Sets the y co-ordinate
     * @param y y co-ordinate
     */
    public void setY(int y) {
        this.y = y;
    }

    /**
     * Gets the x co-ordinate
     * @return x co-ordinate
     */
    public int getX() {
        return x;
    }

    /**
     * Gets the y co-ordinate
     * @return y co-ordinate
     */
    public int getY() {
        return y;
    }
    
}
