package demolition;

import processing.core.PApplet;

public class BombGuy extends Character{
    private int lives;

    /**
     * Constructor for a bombGuy object
     * @param level The Levels object being used by app
     * @param app The PApplet object running the game
     */
    public BombGuy(Levels level, PApplet app){
        super(level, app);
    }

    /**
     * Collision method for bombGuy. Resets level and decrements lives if a death even occurs.
     * If a goal tile is reached it increments the level.
     * @param x co-ordinate to check
     * @param y co-ordinate to check
     */
    public void collision(int x, int y){
        char position = level.getLevelData()[y][x];
        if (position == 'E' || position == 'R' || position == 'Y' || position == 'O') {
            this.lives --;
            level.setReset();
            return;
        } else if (position == 'G')
            level.incrementLv();
    }

    /**
     * The tick method for bombGuy. This gets his x-coordinate if there is a new level,
     * otherwise it just checks collisions.
     */
    public void tick(){
        if (level.getNewLevel()) {
            this.x = level.getBombGuySpawn().getX();
            this.y = level.getBombGuySpawn().getY();
        }
        collision(x, y);
    }
    
    /**
     * Draw method for bombguy. Uses Animate walk method inherited from Character,
     * then provides image to PApplet object
     */
    public void draw(){
        AnimateWalk(currentDirection, animations);
        app.image(this.sprite, x *gridsize, (y - 1) * gridsize + offset);
    }

    /**
     * Handels logic for moving down a square.
     */
    public void pressDown(){
        collision(x, y+1);
        this.currentDirection = 0;
        char down = level.getLevelData()[y+1][x];
        if (down != 'W' && down != 'B'){
            level.appendLevelData(x, x, y, y+1, 'P');
            this.y += 1;
        }
    }
    
    /**
     * Handels logic for moving left a square.
     */
    public void pressLeft(){
        collision(x-1, y);
        this.currentDirection = 1;
        char left = level.getLevelData()[y][x-1];
        if (left != 'W' && left != 'B'){
            level.appendLevelData(x, x-1, y, y, 'P');
            this.x -= 1;
        }
    }
    
    /**
     * Handels logic for moving up a square.
     */
    public void pressUp(){
        collision(x, y-1);
        this.currentDirection = 2;
        char up = level.getLevelData()[y-1][x];
        if (up != 'W' && up != 'B'){
            level.appendLevelData(x, x, y, y-1, 'P');
            this.y -= 1;
        }
    }
    
    /**
     * Handels logic for moving right a square.
     */
    public void pressRight(){
        collision(x+1, y);
        this.currentDirection = 3;
        char right = level.getLevelData()[y][x+1];
        if (right != 'W' && right != 'B'){
            level.appendLevelData(x, x+1, y, y, 'P');
            this.x += 1;
        }
    }

    /**
     * Sets the number of lives for bombGuy to have based off config file.
     * @param lives number of lives.
     */
    public void setLives(int lives) {
        this.lives = lives;
    }

    /**
     * Returns the number of lives bombGuy currently has
     * @return lives
     */
    public int getLives(){
        return this.lives;
    }

    /**
     * Returns true as this is a bombGuy object
     * @return true
     */
    public boolean isBombguy(){
        return true;
    }
}
