package demolition;
import java.util.HashMap;
import processing.core.PApplet;
import processing.core.PFont;
import processing.core.PImage;
import processing.data.JSONArray;
import processing.data.JSONObject;

public class App extends PApplet {
    public static final int WIDTH = 480;
    public static final int HEIGHT = 480;
    public static final int FPS = 60;
    private String configPath = "config.json";
    //End screen text setup
    private int fontSize = 21;
    private int xText = 150;
    private int yText = 200;
    private PFont font;
    private CharacterRender characterRender;
    private Levels levelcreator; //This is the file which will manage level creation and drawing. Aswell as collisions with level objects
    private BombGuy bombGuy;
    private AnimationHolder animationStorage;
    private LivesDisplay livesDisplay;
    private BombsContainer bombsContainer;
    private TimerDisplay timerDisplay;
    //To check if key is being held down
    private HashMap<Integer, Boolean> keys = new HashMap<>();
    private int numberOfLevels;

    /**
     * Constuctor for the app class.
     * Creates all relevent objects in order for the game to function.
     */
    public App() {
        //Creating objects
        this.animationStorage = new AnimationHolder();
        this.characterRender = new CharacterRender();
        this.bombsContainer = new BombsContainer();
        this.levelcreator = new Levels(this, animationStorage, characterRender, bombsContainer);
        this.timerDisplay = new TimerDisplay(this, levelcreator);
        this.bombGuy = new BombGuy(levelcreator, this);
        this.livesDisplay = new LivesDisplay(this, bombGuy);
        characterRender.addCharacter(bombGuy);
    }

    /**
     * Default settings method used by the PApplet class.
     */
    public void settings() {
        size(WIDTH, HEIGHT);
    }

    /**
     * Setup method for the app. This reads the config JSON file,
     * and loads all of the images and fonts for the game. 
     */
    public void setup() {
        frameRate(FPS);
        //Reading json
        JSONObject json = loadJSONObject(configPath);
        JSONArray levels = json.getJSONArray("levels");
        int bombGuyLives = json.getInt("lives");
        //Setting levels and bombguy lives based on config file
        levelcreator.setLevelArray(levels);
        bombGuy.setLives(bombGuyLives);
        numberOfLevels = levels.size();    
        //Creating setup objects.
        RedEnemy setupR = new RedEnemy(null, null, this, null);
        YellowEnemy setupY = new YellowEnemy(null, null, this, null);
        Bomb setupB = new Bomb(-1, -1, null, this, new PImage[9], new PImage[7], false);
        // Load images during setup
        this.levelcreator.setup();
        this.bombGuy.setup("player/");
        setupR.setup("red_enemy/");
        animationStorage.setRedAnimations(setupR.getAnimationsHashMap());
        setupY.setup("yellow_enemy/");
        animationStorage.setYellowAnimations(setupY.getAnimationsHashMap());
        setupB.setup();
        animationStorage.setExploadingSprites(setupB.getExplodingImages());
        animationStorage.setExploadedSprites(setupB.getExplodedImages());
        livesDisplay.setup();
        timerDisplay.setup();
        //Setting font
        fill(0, 0, 0);
        font = this.createFont("PressStart2P-Regular.ttf", fontSize);
        this.textFont(font);
    }

    /**
     * Ticks through all of the objects involves with the game,
     * then draws them all. This method also handles the game win
     * and game lose situations.
     */
    public void draw() {
        background(204, 102, 0);
        if (levelcreator.getLevel() < numberOfLevels && bombGuy.getLives() > 0 && levelcreator.getLevelTime() > 0) { //Execute normal code
            //Tick everything
            levelcreator.tick();
            bombsContainer.tick();
            characterRender.tick();
            livesDisplay.tick();
            timerDisplay.tick();
            //Draw everything.
            levelcreator.draw();
            bombsContainer.draw();
            characterRender.draw();
            livesDisplay.draw();
            timerDisplay.draw();
        }else if (bombGuy.getLives() > 0 && levelcreator.getLevelTime() > 0) { //Display win screen
            text("YOU WIN", xText, yText);
        }else {
            text("GAME OVER", xText, yText);
        }
    }

    /**
     * This method activates when a key is pressed and will call the relevent function.
     */
    public void keyPressed() {
        if (keys.getOrDefault(this.keyCode, false)){

        } else {
            keys.put(this.keyCode, true);
            if (this.keyCode == 37) {
                this.bombGuy.pressLeft();
            } else if (this.keyCode == 38) {
                this.bombGuy.pressUp();
            } else if (this.keyCode == 39) {
                this.bombGuy.pressRight();
            } else if (this.keyCode == 40) {
                this.bombGuy.pressDown();
            } else if (this.keyCode == 32) {
                this.bombsContainer.addBomb(new Bomb(bombGuy.getX(), bombGuy.getY(), levelcreator, this, animationStorage.getExploadingSprites(), animationStorage.getExploadedSprites(), false));
            }
        }
    }

    /**
     * Handels the HashMap which does not allow multiple activations of keyPressed() when
     * holding down a key.
     */
    public void keyReleased(){keys.put(this.keyCode, Boolean.FALSE);}

    /**
     * Sets the configuration file for the app to read. 
     * The default path is "config.json" in the demolition directory
     * @param configPath the new config file path
     */
    public void setConfig(String configPath) {this.configPath = configPath;}

    
    // These are made for testing purposes so are not in the UML diagram. 
    // This will be the case for all other classes
    /**
     * Levels object being used by the app
     * @return levelcreator
     */
    public Levels getLevelCreator() {return this.levelcreator;}

    /**
     * BombsContainer object made by the app
     * @return BombsContainer
     */
    public BombsContainer getBombsContainer() {return this.bombsContainer;}

    public static void main(String[] args) {
        PApplet.main("demolition.App");
    }
}