package demolition;


import java.util.ArrayList;
import java.util.HashMap;

import processing.core.PApplet;
import processing.core.PImage;

public class RedEnemy extends Enemy{


    /**
     * Red Enemy constuctor.
     * @param level Levels object being used by app
     * @param spawn Spawn point
     * @param app PApplet app running the game
     * @param enemyAnimations HashMap of animations based on direction.
     */
    public RedEnemy(Levels level, Point spawn, PApplet app, HashMap<Integer, PImage[]> enemyAnimations){
        super(level, spawn, app, enemyAnimations);
    }

    /**
     * Handles the logic for the RedEnemy deciding where to move. This is random based on its
     * positions that it can move to once it hits a wall.
     */
    public boolean move() {
        ArrayList<Integer> avaliableDirections = this.checkSurroundings();
        if (avaliableDirections.size() == 0)
            return false;   
        for (int i : avaliableDirections) {
            if (currentDirection == i) {
                this.changePosition('R');
                return true;
            }
        }
        int randomIndex = generator.nextInt(avaliableDirections.size());
        int directionMoved = avaliableDirections.get(randomIndex);
        this.currentDirection = directionMoved;
        this.changePosition('R');
        return true;
    }
}
