package demolition;

import java.util.ArrayList;

import java.util.Comparator;

public class CharacterRender {
    
    private ArrayList<Character> characters = new ArrayList<>();

    /**
     * CharacterRender constuctor
     */
    public CharacterRender(){
    }

    /**
     * Tick method, ticks all characters in characters list. 
     * If they are dead it removes them from the character list.
     */
    public void tick(){
        for ( int i = 0; i < characters.size(); i++) {
            characters.get(i).tick();
            if (!characters.get(i).isAlive()){
                characters.remove(i);
                i--;
            }
        }
    }

    /**
     * Draw method, draws all characters on screen using their respective
     * draw method.
     */
    public void draw() {
        characters.sort(compareY);
        for (Character c : characters) {
            c.draw();
        }
    }

    /**
     * Adds a Character object to be ticked and drawn.
     * @param c Character to be added
     */
    public void addCharacter(Character c) {
        characters.add(c);
    }

    /**
     * Removes all Characters from the list unless they are a BombGuy object.
     */
    public void resetCharacters() {
        for ( int i = 0; i < characters.size(); i++) {
            if (!characters.get(i).isBombguy()){
                characters.remove(i);
                i--;
            }
        }
    }

    Comparator<Character> compareY = (c1, c2) -> {
        Integer i1 = c1.getY();
        return i1.compareTo(c2.getY());
    };

    /**
     * For testing, returns the List of characters.
     * @return ArrayList<Character> of characters.
     */
    public ArrayList<Character> getCharacters() {
        return this.characters;
    }

}
