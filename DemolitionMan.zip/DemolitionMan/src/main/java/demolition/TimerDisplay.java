package demolition;

import processing.core.PApplet;
import processing.core.PImage;

public class TimerDisplay {
    
    private int xImage = 256;
    private int xText = 296;
    private int yImage = 15;
    private int yText = 43;
    private int timer;

    private PImage sprite;
    private PApplet app;
    private Levels level;
    
    /**
     * Constructor for the timer Display
     * @param app PApplet App object running the game.
     * @param level Levels object being used by app.
     */
    public TimerDisplay(PApplet app, Levels level) {
        this.app = app;
        this.level = level;
    }

    /**
     * Gets the level time from the Levels object.
     */
    public void tick(){
        timer = level.getLevelTime();
    }

    /**
     * Draws the timerDisplay to the screen.
     */
    public void draw(){
        app.image(sprite, xImage, yImage);
        app.text(timer, xText, yText);
    }
    
    /**
     * Loads the clock image.
     */
    public void setup() {
        sprite = app.loadImage("src/main/resources/icons/clock.png");
    }
}
