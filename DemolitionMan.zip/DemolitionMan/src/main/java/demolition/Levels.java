package demolition;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

import processing.core.PApplet;
import processing.core.PImage;
import processing.data.JSONArray;
import processing.data.JSONObject;

public class Levels {
    private AnimationHolder animationStorage;
    private PApplet app;
    private CharacterRender characterRender;
    private BombsContainer bombsContainer;
    private int currentlevel;
    private char[][] currentLevelData = new char[13][];
    //Spawns
    private boolean newLevel;
    private boolean resetLevel = false;
    private Point bombGuySpawn;
    private ArrayList<Point> redEnemySpawns = new ArrayList<>();
    private ArrayList<Point> yellowEnemySpawns = new ArrayList<>();
    private int tickedlevel = -1;
    private int levelTime = 1;
    private int timer = 0;

    private int offset = 64;
    private int gridsize = 32;
    private JSONArray levelsinfo;
    private PImage wall;
    private PImage empty;
    private PImage broken;
    private PImage goal;
    
    /**
     * Levels object constuctor, default value for currentlevel is 0
     * @param app PApplet App object the game is being run on.
     * @param animationStorage The AnimationHolder object being used by the app
     * @param characterRender The CharacterRender object being used by the app
     * @param bombsContainer The BombsContainer object being used by the app
     */
    public Levels(PApplet app, AnimationHolder animationStorage, CharacterRender characterRender, BombsContainer bombsContainer) {
        this.currentlevel = 0;
        this.app = app;
        this.animationStorage = animationStorage;
        this.characterRender = characterRender;
        this.bombsContainer = bombsContainer;
    }
    
    /**
     * Loads the tile images
     */
    public void setup() {
        this.broken = app.loadImage("src/main/resources/broken/broken.png");
        this.wall = app.loadImage("src/main/resources/wall/solid.png");
        this.empty = app.loadImage("src/main/resources/empty/empty.png");
        this.goal = app.loadImage("src/main/resources/goal/goal.png");
    }

    /**
     * Reads the current level's txt file based off of what is
     * supplied in the config file. Adds this data to a 2-d array of char's
     * @return true is read correctly, false otherwise.
     */
    public boolean readLv(){
        //This reads the text file into a character array.
        JSONObject lvinfoJsonObject = levelsinfo.getJSONObject(currentlevel);
        String lvpath = lvinfoJsonObject.getString("path");
        int lvtime = lvinfoJsonObject.getInt("time");
        levelTime = lvtime;
        try {
            File levelTxt = new File(lvpath);
            Scanner myReader = new Scanner(levelTxt);
            int lineNum = 0;
            while (myReader.hasNextLine()) {
                String line = myReader.nextLine();
                char[] ch = line.toCharArray();
                currentLevelData[lineNum] = ch;
                lineNum ++;
                
            }
            
            myReader.close();
            return true;
        } catch (FileNotFoundException e) {
            System.out.println("Level file was not found.");
            return false;
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Level file must have 13 rows.");
            return false;
        }
    }

    /**
     * Checks if the current level layout is valid.
     * @return true if valid, false otherwise.
     */
    public boolean checkLv(){
        try {
            //Now to check is the level is valid.
            boolean enclosedWalls = false;
            boolean bombGuyOnMap = false;
            boolean goalTileOnMap = false;
            //This checks for if the bomb guy has a spawn and if the goal tile is on the map. Also checks spawns of enemies.
            for (int i = 0; i<13; i++) {
                for (int j = 0; j<15; j++){
                    if (currentLevelData[i][j] == 'P') {
                        bombGuySpawn = new Point(j, i);
                        bombGuyOnMap = true;
                    } else if (currentLevelData[i][j] == 'G') {
                        goalTileOnMap = true;
                    } else if (currentLevelData[i][j] == 'Y') {
                        yellowEnemySpawns.add(new Point(j, i));
                    } else if (currentLevelData[i][j] == 'R') {
                        redEnemySpawns.add(new Point(j, i));
                    }
                }
            }
            if (!bombGuyOnMap || !goalTileOnMap) {
                throw new NeglectedTileException();
            }
            //This loop will be used to check if the level is enclosed
            boolean topClosed = false;
            boolean notEnclosed = false;
            for (int i = 0; i<currentLevelData.length; i++) {
                if (!notEnclosed) {
                    if (currentLevelData[i][0] == 'W') {
                        //Checks for when there is the first wall, when there is the first wall the entire top must be closed
                        if (!topClosed) {
                            for (int j = 0; j < currentLevelData[i].length; j++){
                                if (currentLevelData[i][j] != 'W') {
                                    notEnclosed = true;
                                    break;
                                }
                            }
                            topClosed = true;
                        //After the top is confirmed to be enclosed.
                        } else if (topClosed) {
                            //First check that both side walls ie. the leftmost and rightmost walls are closed.
                            if (currentLevelData[i][14] != 'W') {
                                notEnclosed = true;
                                continue;
                            }
                            //If they are then check each position along that line. If they are all walls then the bottom is found
                            //And the map is enclosed.
                            for (int j = 0; j < currentLevelData[i].length; j++){
                                if (currentLevelData[i][j] != 'W') {
                                    break;
                                }
                                if (j == 14) {
                                    enclosedWalls = true;
                                }
                            }
                        }
                    }
                } else {
                    break;
                }
            }
            if (!enclosedWalls){
                throw new NonEnclosedLevelException();
            }
            return true;
        //Figure out what to do when a level is incorrect.
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Level file must have rows with 15 characters.");
            return false;
        } catch (NeglectedTileException e){
            System.out.println("Both goal and spawn tile must be set.");
            return false;
        } catch (NonEnclosedLevelException e){
            System.out.println("The tiles must be fully enclosed by an unbroken rectangle of walls on the edges.");
            return false;
        }
    }

    /**
     * Creates the Enemy object based on the level data.
     */
    public void createEnemies() {
        for (Point point : redEnemySpawns) {
            RedEnemy temp = new RedEnemy(this, point, app, animationStorage.getRedAnimations());
            characterRender.addCharacter(temp);

        }
        for (Point point : yellowEnemySpawns) {
            YellowEnemy temp = new YellowEnemy(this, point, app, animationStorage.getYellowAnimations());
            characterRender.addCharacter(temp);
        }
    }

    /**
     * If a new level is loaded or the level is reset, this tick method handels the logic behind it. 
     * This method also decrements the level time.
     */
    public void tick() {
        if (tickedlevel != currentlevel || resetLevel){
            resetLevel = false;
            resetSpawnPoints();
            characterRender.resetCharacters();
            bombsContainer.resetbombs();
            readLv();
            checkLv();
            createEnemies();
            tickedlevel = currentlevel;
            newLevel = true;
        }else {
            newLevel = false;
        }

        if (timer > App.FPS) {
            levelTime --;
            timer = 0;
        }
        timer ++;
    }

    /**
     * The draw method for the tiles on the level.
     */
    public void draw() {
        for (int i = 0; i < currentLevelData.length; i ++) {
            for (int j = 0; j < currentLevelData[i].length; j++) {
                char walltype = currentLevelData[i][j];
                if (walltype == 'W') {
                    app.image(wall, gridsize * j, gridsize*i + offset);
                } else if (walltype == 'B') {
                    app.image(broken, gridsize * j, gridsize*i + offset);
                } else if (walltype == 'G' || walltype == 'O') {
                    app.image(goal, gridsize * j, gridsize*i + offset);
                } else {
                    app.image(empty, gridsize * j, gridsize*i + offset);
                }
            }
        }
    }

    /**
     * Returns the current data of the level.
     * @return char[][] a 2d array of characters, with [y][x]
     */
    public char[][] getLevelData() {
        return this.currentLevelData;
    }

    /**
     * Changes the current level data based on what needs to change.
     * @param oldX old x value of object being moved.
     * @param newX new x value of object being moved.
     * @param oldY old y value of object being moved.
     * @param newY new y value of object being moved.
     * @param c the char representing the type of object being changed.
     */
    public void appendLevelData(int oldX, int newX, int oldY, int newY, char c) {
        if (currentLevelData[newY][newX] == 'G') {
            currentLevelData[oldY][oldX] = ' ';
            currentLevelData[newY][newX] = 'O';
        } else if (currentLevelData[oldY][oldX] == 'O' && c != 'P'){
            currentLevelData[newY][newX] = c;
            currentLevelData[oldY][oldX] = 'G';
        } else if (currentLevelData[newY][newX] == 'O' && c == 'P'){
            currentLevelData[oldY][oldX] = ' ';
        } else {
            currentLevelData[oldY][oldX] = ' ';
            currentLevelData[newY][newX] = c;
        }
    }

    /**
     * Increments the current level
     */
    public void incrementLv(){
        this.currentlevel ++;
    }

    /**
     * Gets the current level
     * @return int current level, eg lv1 = 0
     */
    public int getLevel() {
        return this.currentlevel;
    }

    /**
     * Returns the bombGuysSpawn location for the current level.
     * @return Point.
     */
    public Point getBombGuySpawn() {
        return bombGuySpawn;
    }

    /**
     * Returns if a new level was just loaded.
     * @return true if new level, otherwise false.
     */
    public boolean getNewLevel(){
        return this.newLevel;
    }

    /**
     * Allows other objects to set the level to reset.
     */
    public void setReset(){
        this.resetLevel = true;
    }

    /**
     * Resets tge spawn points of the enemy's
     */
    public void resetSpawnPoints() {
        redEnemySpawns = new ArrayList<>();
        yellowEnemySpawns = new ArrayList<>();
    }

    /**
     * Gets the time remaining for the level.
     * @return integer of time remaining.
     */
    public int getLevelTime() {
        return this.levelTime;
    }

    /**
     * Sets the JSONArray that the level information is read from
     * @param levelsInfo JSONArray that path and time data is read from.
     */
    public void setLevelArray(JSONArray levelsInfo) {
        this.levelsinfo = levelsInfo;
    }

    /**
     * Returns the list of RedEnemy Spawns
     * @return ArrayList<Point>
     */
    public ArrayList<Point> getRedEnemySpawns(){
        return this.redEnemySpawns;
    }

    /**
     * Returns the list of YellowEnemy Spawns
     * @return ArrayList<Point>
     */
    public ArrayList<Point> getYellowEnemySpawns(){
        return this.yellowEnemySpawns;
    }
}

class NeglectedTileException extends Exception {
    public NeglectedTileException(){
        super("Both goal and spawn tile must be set.");
    }
}

class NonEnclosedLevelException extends Exception {
    public NonEnclosedLevelException(){
        super("The tiles must be fully enclosed by an unbroken rectangle of walls on the edges.");
    }
}
