package demolition;

import processing.core.PApplet;
import processing.core.PImage;

public class LivesDisplay {

    private int xImage = 128;
    private int xText = 169;
    private int yImage = 15;
    private int yText = 43;
    private int lives;

    private PImage sprite;
    private PApplet app;
    private BombGuy bombGuy;
    
    /**
     * Constructor for the lives Display
     * @param app PApplet App object running the game.
     * @param bombGuy BombGuy object being used by the game.
     */
    public LivesDisplay(PApplet app, BombGuy bombGuy) {
        this.app = app;
        this.bombGuy = bombGuy;
    }

    /**
     * Checks the number of lives bombguy has.
     */
    public void tick(){
        this.lives = bombGuy.getLives();
    }

    /**
     * Draws the sprite of BombGuy's head and the number of lives onto the screen
     */
    public void draw(){
        app.image(sprite, xImage, yImage);
        app.text(lives, xText, yText);
    }
    
    /**
     * Loads the sprite of bombguy's head.
     */
    public void setup() {
        sprite = app.loadImage("src/main/resources/icons/player.png");
    }
}
