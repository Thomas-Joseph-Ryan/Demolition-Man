package demolition;

import java.util.HashMap;

import processing.core.PApplet;
import processing.core.PImage;

public abstract class Character implements GameObject{
    protected PApplet app;
    protected boolean alive;
    protected HashMap<Integer, PImage[]> animations = new HashMap<>();
    private static final double SECONDS_BETWEEN_MOVES = 0.2;
    private int timer;
    protected int currentDirection;
    protected Levels level;
    protected PImage sprite;
    protected int offset = 80;
    protected int gridsize = 32;
    protected int x;
    protected int y;

    /**
     * Character constuctor, the parent class for BombGuy, 
     * and Enemy classes.
     * @param level Levels object being used by app
     * @param app PApplet object running the game
     */
    public Character(Levels level, PApplet app){
        alive = true;
        currentDirection = 0;
        this.level = level;
        this.app = app;
    }

    /**
     * Creates a HashMap with keys 0, 1, 2, 3 respectively mapping to
     * down, left, up, right sprites. 
     * @param down PImage array of sprites when walking down
     * @param left PImage array of sprites when walking left
     * @param up PImage array of sprites when walking up
     * @param right PImage array of sprites when walking right
     */
    protected void CreateAnimationMap(PImage[] down, PImage[] left, PImage[] up, PImage[] right){
        animations.put(0, down);
        animations.put(1, left);
        animations.put(2, up);
        animations.put(3, right);
    }

    /**
     * Assigns what sprite the object should currently be using.
     * @param direction current direction being moved.
     * @param animations the HashMap of sprites.
     */
    protected void AnimateWalk(int direction, HashMap<Integer, PImage[]> animations){
        //This method will take an integer from its subclasses, and animate the sprite according to the direction they are facing.
        //This will happen with 0 : down, 1 : left, 2 : up, 3 : right.
        timer ++;
        if (currentDirection != direction){
            currentDirection = direction;
            this.sprite = animations.get(direction)[0];
            this.timer = 0;
        } else {
            if (timer < SECONDS_BETWEEN_MOVES * App.FPS){
                this.sprite = animations.get(direction)[0];
            }else if (timer < SECONDS_BETWEEN_MOVES * App.FPS * 2){
                this.sprite = animations.get(direction)[1];
            }else if (timer < SECONDS_BETWEEN_MOVES * App.FPS* 3){
                this.sprite = animations.get(direction)[2];
            }else if (timer < SECONDS_BETWEEN_MOVES * App.FPS* 4){
                this.sprite = animations.get(direction)[3];
            }else if (timer < SECONDS_BETWEEN_MOVES * App.FPS * 5){
                this.timer = 0;
            }
        }
    }

    /**
     * The setup method for Character objects. It loads all
     * relevent sprites, assigns them to their respective array, 
     * then uses the CreateAnimationMap array.
     * @param directory The directory keyword for what Character object sprite to setup.
     */
    protected void setup(String directory){
        PImage[] down = new PImage[4];
        PImage[] left = new PImage[4];
        PImage[] up = new PImage[4];
        PImage[] right = new PImage[4];

        for (int i = 0; i < 4; i++) {
             String imageName = "src/main/resources/" + directory + "down" + (i+1) + ".png";
             down[i] = app.loadImage(imageName);
        }
        for (int i = 0; i < 4; i++) {
             String imageName = "src/main/resources/" + directory + "left" + (i+1) + ".png";
             left[i] = app.loadImage(imageName);
        }
        for (int i = 0; i < 4; i++) {
             String imageName = "src/main/resources/" + directory + "up" + (i+1) + ".png";
             up[i] = app.loadImage(imageName);
        }
        for (int i = 0; i < 4; i++) {
             String imageName = "src/main/resources/" + directory + "right" + (i+1) + ".png";
             right[i] = app.loadImage(imageName);
        }
        this.CreateAnimationMap(down, left, up, right);
    }

    /**
     * Returns the HashMap of animation sprites.
     * @return HashMap
     */
    public HashMap<Integer, PImage[]> getAnimationsHashMap(){
        return this.animations;
    }

    /**
     * Returns Y co-ordinate of Character object
     * @return integer of y co-ordinate
     */
    public int getY(){
        return this.y;
    }

    /**
     * Returns X co-ordinate of Character object
     * @return integer of x co-ordinate
     */
    public int getX() {
        return this.x;
    }

    /**
     * Returns if the current Character is alive.
     * @return true if alive, false if dead.
     */
    public boolean isAlive() {
        return this.alive;
    }

    /**
     * Abstract draw method that must be implemented by child class
     */
    public abstract void draw();

    /**
     * Abstract tick method that must be implemented by child class
     */
    public abstract void tick();

    /**
     * Abstract method that must be implemented by child class.
     */
    public abstract boolean isBombguy();

    /**
     * Abstract collision method that must be implemented by child class
     */
    public abstract void collision(int x, int y);
    
}
