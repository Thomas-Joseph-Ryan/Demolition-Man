package demolition;

import processing.core.PApplet;
import processing.core.PImage;

public class Bomb implements GameObject{

    private int timer;
    private int stage;
    private Levels level;
    private PApplet app;

    private int x;
    private int y;
    private int offset = 64;
    private int gridsize = 32;
    private double timeBetweenExplodingStates = 0.25;
    private double explosionExistenceTime = 0.5;
    private boolean exists;
    private boolean exploded;
    //Creating boolean of what explosion path it will take, these are public for testing
    public boolean centre = true;
    public boolean oneDown = false;
    public boolean twoDown = false;
    public boolean oneUp = false;
    public boolean twoUp = false;
    public boolean oneLeft = false;
    public boolean twoLeft = false;
    public boolean oneRight = false;
    public boolean twoRight = false;

    private PImage[] explodingSprites;
    private PImage[] explodedSprites; //index 0: centre, 1: Horizontal, 2: Vertical, 3: End_bottom, 4: End_top, 5: End_right, 6: End_left.
    private PImage sprite;

    //For testing
    private boolean isTest = false;

    /**
     * The constructor for a Bomb object.
     * Default state for exists is true and exploded is false
     * @param x x-coordinate that the bomb will spawn
     * @param y y-coordinate that the bomb will spawn
     * @param level the Levels object that is handelling the level it will be placed on
     * @param app The App that is handelling the game
     * @param exploading The PImage array for the exploading sprites
     * @param exploaded The PImage array for the exploaded sprites
     * @param isTest A boolean specifying whether this bomb is made in a testcase scenario
     */
    public Bomb(int x, int y, Levels level, PApplet app, PImage[] exploading, PImage[] exploaded, boolean isTest){
        this.x = x;
        this.y = y;
        this.level = level;
        this.app = app;
        this.exists = true;
        this.exploded = false;
        this.stage = 0;
        this.explodingSprites = exploading;
        this.explodedSprites = exploaded;
        this.isTest = isTest;
        if (!this.isTest)
            this.sprite = this.explodingSprites[0];
    }

    /**
     * A collision method required by the GameObject interface.
     */
    public void collision(int x, int y){
    }

    /**
     * A method to change the level data depending on where the bomb can
     * explode.  
     * @param c The char to replace the level data with.
     */
    public void appendExplosionData(char c) {
        if (centre) {
            level.appendLevelData(x, x, y, y, c);
        }
        if (oneUp) {
            level.appendLevelData(x, x, y-1, y-1, c);
        }
        if (twoUp) {
            level.appendLevelData(x, x, y-2, y-2, c);
        }
        if (oneDown) {
            level.appendLevelData(x, x, y+1, y+1, c);
        }
        if (twoDown) {
            level.appendLevelData(x, x, y+2, y+2, c);
        }
        if (oneLeft) {
            level.appendLevelData(x-1, x-1, y, y, c);
        }
        if (twoLeft) {
            level.appendLevelData(x-2, x-2, y, y, c);
        }
        if (oneRight) {
            level.appendLevelData(x+1, x+1, y, y, c);
        }
        if (twoRight) {
            level.appendLevelData(x+2, x+2, y, y, c);
        }
    }

    /**
     * Finds where the bomb can explode depending on what tiles surround
     * it. Whereever the bomb can explode it changes the respective boolean
     * to true.
     */
    public void getExplosionLocations() {
        char[][] currentLevelData = level.getLevelData();
        //Checking top of bomb
        if (currentLevelData[y-1][x] != 'W'){
            oneUp = true;
            if (currentLevelData[y-1][x] != 'B' && currentLevelData[y-2][x] != 'W')
                twoUp = true;
        }
        //Checking bottom of bomb
        if (currentLevelData[y+1][x] != 'W'){
            oneDown = true;
            if (currentLevelData[y+1][x] != 'B' && currentLevelData[y+2][x] != 'W')
                twoDown = true;
        }
        //Checking left of bomb
        if (currentLevelData[y][x-1] != 'W'){
            oneLeft = true;
            if (currentLevelData[y][x-1] != 'B' && currentLevelData[y][x-2] != 'W')
                twoLeft = true;
        }
        //Checking right of bomb
        if (currentLevelData[y][x+1] != 'W'){
            oneRight = true;
            if (currentLevelData[y][x+1] != 'B' && currentLevelData[y][x+2] != 'W')
                twoRight = true;
        }
    }

    /**
     * This ticks through the bombs logic and keeps the timing of each bomb.
     */
    public void tick(){
        if (!exploded && timer > timeBetweenExplodingStates * App.FPS * stage && stage < 9) {
            if (!isTest)
                this.sprite = explodingSprites[stage];
            stage ++;
        } else if (!exploded && stage == 9){
            exploded = true;
            getExplosionLocations();
            appendExplosionData('E');
            timer = 0;
        }
        if (exploded && timer > explosionExistenceTime * App.FPS) {
            appendExplosionData(' ');
            this.exists = false;
        }
        timer++;
    }

    /**
     * Draws the bomb depending on what state it is in.
     */
    public void draw(){
        if (!exploded)
            app.image(this.sprite, x *gridsize, y * gridsize + offset);
        if (exploded && exists){
            if (centre) {
                app.image(explodedSprites[0], x *gridsize, y * gridsize + offset);;
            }
            if (oneUp) {
                app.image(explodedSprites[2], x *gridsize, (y-1) * gridsize + offset);
            }
            if (twoUp) {
                app.image(explodedSprites[4], x *gridsize, (y-2) * gridsize + offset);
            }
            if (oneDown) {
                app.image(explodedSprites[2], x *gridsize, (y+1) * gridsize + offset);
            }
            if (twoDown) {
                app.image(explodedSprites[3], x *gridsize, (y+2) * gridsize + offset);
            }
            if (oneLeft) {
                app.image(explodedSprites[1], (x-1) *gridsize, y * gridsize + offset);
            }
            if (twoLeft) {
                app.image(explodedSprites[6], (x-2) *gridsize, y * gridsize + offset);
            }
            if (oneRight) {
                app.image(explodedSprites[1], (x+1) *gridsize, y * gridsize + offset);
            }
            if (twoRight) {
                app.image(explodedSprites[5], (x+2) *gridsize, y * gridsize + offset);
            }
        }

    }

    /**
     * Loads all of the bombs sprites.
     */
    public void setup(){
        explodingSprites[0] = app.loadImage("src/main/resources/bomb/bomb.png");
        explodingSprites[1] = app.loadImage("src/main/resources/bomb/bomb1.png");
        explodingSprites[2] = app.loadImage("src/main/resources/bomb/bomb2.png");
        explodingSprites[3] = app.loadImage("src/main/resources/bomb/bomb3.png");
        explodingSprites[4] = app.loadImage("src/main/resources/bomb/bomb4.png");
        explodingSprites[5] = app.loadImage("src/main/resources/bomb/bomb5.png");
        explodingSprites[6] = app.loadImage("src/main/resources/bomb/bomb6.png");
        explodingSprites[7] = app.loadImage("src/main/resources/bomb/bomb7.png");
        explodingSprites[8] = app.loadImage("src/main/resources/bomb/bomb8.png");

        explodedSprites[0] = app.loadImage("src/main/resources/explosion/centre.png");
        explodedSprites[1] = app.loadImage("src/main/resources/explosion/horizontal.png");
        explodedSprites[2] = app.loadImage("src/main/resources/explosion/vertical.png");
        explodedSprites[3] = app.loadImage("src/main/resources/explosion/end_bottom.png");
        explodedSprites[4] = app.loadImage("src/main/resources/explosion/end_top.png");
        explodedSprites[5] = app.loadImage("src/main/resources/explosion/end_right.png");
        explodedSprites[6] = app.loadImage("src/main/resources/explosion/end_left.png");
    }

    /**
     * Gets the PImage array of the bomb before it explodes to pass into the animation holder
     * @return PImage array of sprites before the bomb explodes.
     */
    public PImage[] getExplodingImages(){
        return this.explodingSprites;
    }

    /**
     * Gets the PImage array of the bomb when it explodes to pass into the animation holder
     * @return PImage array of sprites before the bomb explodes
     */
    public PImage[] getExplodedImages(){
        return this.explodedSprites;
    }

    /**
     * Gets a boolean of whether or not the bomb still exists
     * @return True if bomb has not finished its explosion, otherwise false.
     */
    public boolean getExistenceState() {
        return this.exists;
    }
}
