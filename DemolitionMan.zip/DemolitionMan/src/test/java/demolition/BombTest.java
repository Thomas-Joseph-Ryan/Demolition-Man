package demolition;

import org.junit.jupiter.api.Test;

import processing.data.JSONArray;
import processing.data.JSONObject;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;

public class BombTest {
    
    Levels levelcreator;
    
    @BeforeEach
    public void setUp() {
        JSONArray json = new JSONArray();

        JSONObject level1 = new JSONObject();
        level1.setString("path", "src/test/resources/bombTest.txt");
        level1.setInt("time", 180);
        json.setJSONObject(0, level1);

        //Creating levelcreator with all of its dependencies
        AnimationHolder AH = new AnimationHolder();
        CharacterRender CR = new CharacterRender();
        BombsContainer BC = new BombsContainer();
        Levels levelcreator = new Levels(null, AH, CR, BC);
        this.levelcreator = levelcreator;
        levelcreator.setLevelArray(json);
        levelcreator.tick();
        levelcreator.tick();
    }

    @Test
    public void constructor() {
        assertNotNull(new Bomb(1, 1, levelcreator, null, null, null, true));
    }

    @Test
    public void checkBombLocationsFullReach() {
        Bomb bomb = new Bomb(3, 6, levelcreator, null, null, null, true);
        bomb.getExplosionLocations();
        assertTrue(bomb.centre);
        assertTrue(bomb.oneUp);
        assertTrue(bomb.oneDown);
        assertTrue(bomb.oneLeft);
        assertTrue(bomb.oneRight);
        assertTrue(bomb.twoDown);
        assertTrue(bomb.twoUp);
        assertTrue(bomb.twoLeft);
        assertTrue(bomb.twoRight);
        bomb.appendExplosionData('E');
    }

    @Test
    public void checkBombLocationsCentreOnly() {
        Bomb bomb = new Bomb(2, 2, levelcreator, null, null, null, true);
        bomb.getExplosionLocations();
        assertTrue(bomb.centre);
        assertFalse(bomb.oneUp);
        assertFalse(bomb.oneDown);
        assertFalse(bomb.oneLeft);
        assertFalse(bomb.oneRight);
        assertFalse(bomb.twoDown);
        assertFalse(bomb.twoUp);
        assertFalse(bomb.twoLeft);
        assertFalse(bomb.twoRight);
        bomb.appendExplosionData('E');
    }

    @Test
    public void checkBombLocationsOneLengthWall() {
        Bomb bomb = new Bomb(8, 10, levelcreator, null, null, null, true);
        bomb.getExplosionLocations();
        assertTrue(bomb.centre);
        assertTrue(bomb.oneUp);
        assertTrue(bomb.oneDown);
        assertTrue(bomb.oneLeft);
        assertTrue(bomb.oneRight);
        assertFalse(bomb.twoDown);
        assertFalse(bomb.twoUp);
        assertFalse(bomb.twoLeft);
        assertFalse(bomb.twoRight);
        bomb.appendExplosionData('E');
    }

    @Test
    public void checkBombLocationsOneLengthBrokenWall() {
        Bomb bomb = new Bomb(10, 5, levelcreator, null, null, null, true);
        bomb.getExplosionLocations();
        assertTrue(bomb.centre);
        assertTrue(bomb.oneUp);
        assertTrue(bomb.oneDown);
        assertTrue(bomb.oneLeft);
        assertTrue(bomb.oneRight);
        assertFalse(bomb.twoDown);
        assertFalse(bomb.twoUp);
        assertFalse(bomb.twoLeft);
        assertFalse(bomb.twoRight);
        bomb.appendExplosionData('E');
    }
}
