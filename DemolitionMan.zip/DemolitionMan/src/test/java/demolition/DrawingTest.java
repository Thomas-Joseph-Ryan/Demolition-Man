package demolition;

import processing.core.PApplet;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class DrawingTest {
    //Majority of testing of the character class will be done in this testclass
    //This is because most of the methods in that class rely on an instance of PImage
    //These are not accessible outside of an instance of the app class.
    @Test 
    public void testSetupAndDraw() {
        // Create an instance of your application
        App app = new App();

        // Set the program to not loop automatically
        app.noLoop();

        // Set the path of the config file to use
        app.setConfig("src/test/resources/config.json");

        // Tell PApplet to create the worker threads for the program
        PApplet.runSketch(new String[] {"App"}, app);

        // Call App.setup() to load in sprites
        app.setup();

        // Set a 1 second delay to ensure all resources are loaded
        app.delay(1000);

        // Call draw to update the program.
        app.draw();
    }

    @Test 
    public void testBombDraw() {
        // Create an instance of your application
        App app = new App();

        // Set the program to not loop automatically
        app.noLoop();

        // Set the path of the config file to use
        app.setConfig("src/test/resources/config.json");

        // Tell PApplet to create the worker threads for the program
        PApplet.runSketch(new String[] {"App"}, app);

        // Call App.setup() to load in sprites
        app.setup();

        // Set a 1 second delay to ensure all resources are loaded
        app.delay(1000);

        // Call draw to update the program.
        app.draw();

        //Place a bomb on the screen and get bombGuy out of the way
        //Press space
        app.keyCode = 32;
        app.keyPressed();
        app.keyReleased();
        app.draw();
        //Press right 3 times
        app.keyCode = 39;
        app.keyPressed();
        app.keyReleased();
        app.draw();
        app.keyPressed();
        app.keyReleased();
        app.draw();
        app.keyPressed();
        app.keyReleased();
        app.draw();
        
        //Now bomb should be on screen, so check that bombcontainer has a bomb.
        assertEquals(1, app.getBombsContainer().getBombListSize());
        for (int i = 0; i < 181; i++){
            app.draw();
        }
        //Bomb should now be exploded, so we will check that the container no longer has the bomb.
        assertEquals(0, app.getBombsContainer().getBombListSize());
        
        //Now to place a bomb where it can explode in all directions
        //Go right once
        app.keyPressed();
        app.keyReleased();
        app.draw();
        //Go down twice
        app.keyCode = 40;
        app.keyPressed();
        app.keyReleased();
        app.draw();
        app.keyPressed();
        app.keyReleased();
        app.draw();
        //Place Bomb
        app.keyCode = 32;
        app.keyPressed();
        app.keyReleased();
        app.draw();
        //Leave area so bombguy doesnt die
        //Up twice
        app.keyCode = 38;
        app.keyPressed();
        app.keyReleased();
        app.draw();
        app.keyPressed();
        app.keyReleased();
        app.draw();
        //Left once
        app.keyCode = 37;
        app.keyPressed();
        app.keyReleased();
        app.draw();
        //Let bomb explode
        for (int i = 0; i < 181; i++){
            app.draw();
        }
    }
    
}
