package demolition;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import processing.data.JSONArray;
import processing.data.JSONObject;



public class LevelTest {
    JSONArray json;
    
    @BeforeEach
    public void setUp() {
        JSONArray json = new JSONArray();

        JSONObject level1 = new JSONObject();
        level1.setString("path", "src/test/resources/level1.txt");
        level1.setInt("time", 180);
        json.setJSONObject(0, level1);

        JSONObject level2 = new JSONObject();
        level2.setString("path", "src/test/resources/level2.txt");
        level2.setInt("time", 180);
        json.setJSONObject(1, level2);
        
        this.json = json;
    }

    @Test
    public void constuctor(){
        assertNotNull(new Levels(null, null, null, null));
    }

    @Test  
    public void readLevel(){
        Levels levelcreator = new Levels(null, null, null, null);
        levelcreator.setLevelArray(json);
        assertTrue(levelcreator.readLv());
        assertTrue(levelcreator.checkLv());
        levelcreator.incrementLv();
        assertTrue(levelcreator.readLv());
        assertTrue(levelcreator.checkLv());
        assertNotNull(levelcreator.getLevelData());
    }

    @Test
    public void testFileNotFoundException() {
        JSONObject level3 = new JSONObject();
        level3.setString("path", "level3.txt");
        level3.setInt("time", 180);
        json.setJSONObject(2, level3);
        Levels levelcreator = new Levels(null, null, null, null);
        levelcreator.setLevelArray(json);
        levelcreator.incrementLv();
        levelcreator.incrementLv();
        assertFalse(levelcreator.readLv());
    }

    @Test
    public void testArrayOutOfBoundsException() {
        JSONObject level3 = new JSONObject();
        level3.setString("path", "src/test/resources/nullpointerlevel.txt");
        level3.setInt("time", 180);
        json.setJSONObject(2, level3);
        Levels levelcreator = new Levels(null, null, null, null);
        levelcreator.setLevelArray(json);
        levelcreator.incrementLv();
        levelcreator.incrementLv();
        levelcreator.readLv();
        assertFalse(levelcreator.checkLv());
    }

    @Test
    public void testNeglectedTileException() {
        JSONObject level3 = new JSONObject();
        level3.setString("path", "src/test/resources/neglectedtilelevel.txt");
        level3.setInt("time", 180);
        json.setJSONObject(2, level3);
        Levels levelcreator = new Levels(null, null, null, null);
        levelcreator.setLevelArray(json);
        levelcreator.incrementLv();
        levelcreator.incrementLv();
        levelcreator.readLv();
        assertFalse(levelcreator.checkLv());
    }

    @Test
    public void testNonEnclosedLevelException1() {
        JSONObject level3 = new JSONObject();
        level3.setString("path", "src/test/resources/nonenclosedlevel1.txt");
        level3.setInt("time", 180);
        json.setJSONObject(2, level3);
        Levels levelcreator = new Levels(null, null, null, null);
        levelcreator.setLevelArray(json);
        levelcreator.incrementLv();
        levelcreator.incrementLv();
        levelcreator.readLv();
        assertFalse(levelcreator.checkLv());
    }

    @Test
    public void testNonEnclosedLevelException2() {
        JSONObject level3 = new JSONObject();
        level3.setString("path", "src/test/resources/nonenclosedlevel2.txt");
        level3.setInt("time", 180);
        json.setJSONObject(2, level3);
        Levels levelcreator = new Levels(null, null, null, null);
        levelcreator.setLevelArray(json);
        levelcreator.incrementLv();
        levelcreator.incrementLv();
        levelcreator.readLv();
        assertFalse(levelcreator.checkLv());
    }

    @Test
    public void testEnemyCreation() {
        JSONObject level3 = new JSONObject();
        level3.setString("path", "src/test/resources/MultipleEnemies.txt");
        level3.setInt("time", 180);
        json.setJSONObject(2, level3);
        CharacterRender CR = new CharacterRender();
        AnimationHolder AH = new AnimationHolder();
        Levels levelcreator = new Levels(null, AH, CR, null);
        levelcreator.setLevelArray(json);
        levelcreator.incrementLv();
        levelcreator.incrementLv();
        levelcreator.readLv();
        levelcreator.checkLv();
        assertEquals(4, levelcreator.getRedEnemySpawns().size());
        assertEquals(2, levelcreator.getYellowEnemySpawns().size());
        levelcreator.createEnemies();
        assertEquals(6, CR.getCharacters().size());
    }

    @Test
    public void testAppendLevelData() {
        Levels levelcreator = new Levels(null, null, null, null);
        levelcreator.setLevelArray(json);
        levelcreator.readLv();
        levelcreator.checkLv();
        assertEquals(levelcreator.getLevelData()[1][1], 'P');
        assertEquals(levelcreator.getLevelData()[1][2], ' ');
        levelcreator.appendLevelData(1, 2, 1, 1, 'P');
        assertEquals(levelcreator.getLevelData()[1][1], ' ');
        assertEquals(levelcreator.getLevelData()[1][2], 'P');
    }

    @Test
    public void testOccupyingGoalTile() {
        Levels levelcreator = new Levels(null, null, null, null);
        levelcreator.setLevelArray(json);
        levelcreator.readLv();
        levelcreator.checkLv();
        assertEquals(levelcreator.getLevelData()[11][13], 'G');
        levelcreator.appendLevelData(12, 13, 11, 11, 'R');
        assertEquals(levelcreator.getLevelData()[11][13], 'O');
        levelcreator.appendLevelData(13, 13, 11, 10, 'R');
        assertEquals(levelcreator.getLevelData()[11][13], 'G');
        assertEquals(levelcreator.getLevelData()[10][13], 'R');
        levelcreator.appendLevelData(12, 13, 11, 11, 'R');
        levelcreator.appendLevelData(12, 13, 11, 11, 'P');
        assertEquals(levelcreator.getLevelData()[11][13], 'O');
    }

    @Test
    public void testTick() {
        //Creating levelcreator with all of its dependencies
        AnimationHolder AH = new AnimationHolder();
        CharacterRender CR = new CharacterRender();
        BombsContainer BC = new BombsContainer();
        Levels levelcreator = new Levels(null, AH, CR, BC);
        levelcreator.setLevelArray(json);
        for (int i = 0; i < 120; i++) {
            levelcreator.tick();
        }
    }
}
