package demolition;

import org.junit.jupiter.api.Test;

import processing.data.JSONArray;
import processing.data.JSONObject;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;

public class BombGuyTest {

    Levels levelcreator;
    BombGuy bombGuy;
    
    @BeforeEach
    public void setUp() {
        JSONArray json = new JSONArray();

        JSONObject level1 = new JSONObject();
        level1.setString("path", "src/test/resources/level1.txt");
        level1.setInt("time", 180);
        json.setJSONObject(0, level1);

        JSONObject level2 = new JSONObject();
        level2.setString("path", "src/test/resources/level2.txt");
        level2.setInt("time", 180);
        json.setJSONObject(1, level2);
        
        JSONObject level3 = new JSONObject();
        level3.setString("path", "src/test/resources/testtile.txt");
        level3.setInt("time", 180);
        json.setJSONObject(2, level3);
        //Creating levelcreator with all of its dependencies
        AnimationHolder AH = new AnimationHolder();
        CharacterRender CR = new CharacterRender();
        BombsContainer BC = new BombsContainer();
        Levels levelcreator = new Levels(null, AH, CR, BC);
        this.levelcreator = levelcreator;
        levelcreator.setLevelArray(json);
        BombGuy bombGuy = new BombGuy(levelcreator, null);
        this.bombGuy = bombGuy;
        levelcreator.tick();
        bombGuy.tick();
        levelcreator.tick();
    }
    
    @Test
    public void constructor() {
        assertNotNull(new BombGuy(levelcreator, null));
    }

    @Test
    public void testPressDown() {
        assertEquals(1, bombGuy.getY());
        assertEquals(1, bombGuy.getX());
        bombGuy.pressDown();
        assertEquals(2, bombGuy.getY());
        assertEquals(1, bombGuy.getX());
        //Get him to hit a wall
        bombGuy.pressUp();
        bombGuy.pressRight();
        bombGuy.pressDown();
        assertEquals(1, bombGuy.getY());
        assertEquals(2, bombGuy.getX());
        //Get him to hit a BrokenWall
        bombGuy.pressLeft();
        bombGuy.pressDown();
        bombGuy.pressDown();
        bombGuy.pressDown();
        bombGuy.pressDown();
        assertEquals(3, bombGuy.getY());
    }

    @Test
    public void testPressUp() {
        assertEquals(1, bombGuy.getY());
        assertEquals(1, bombGuy.getX());
        bombGuy.pressUp();
        assertEquals(1, bombGuy.getY());
        assertEquals(1, bombGuy.getX());
        bombGuy.pressDown();
        assertEquals(2, bombGuy.getY());
        assertEquals(1, bombGuy.getX());
        bombGuy.pressUp();
        assertEquals(1, bombGuy.getY());
        assertEquals(1, bombGuy.getX());
        //Look for broken wall
        bombGuy.pressDown();
        bombGuy.pressDown();
        bombGuy.pressRight();
        bombGuy.pressRight();
        bombGuy.pressRight();
        bombGuy.pressRight();
        bombGuy.pressRight();
        bombGuy.pressRight();
        bombGuy.pressUp();
        bombGuy.pressUp();
        assertEquals(2, bombGuy.getY());
    }

    @Test
    public void testPressRight() {
        assertEquals(1, bombGuy.getY());
        assertEquals(1, bombGuy.getX());
        bombGuy.pressRight();
        assertEquals(1, bombGuy.getY());
        assertEquals(2, bombGuy.getX());
        bombGuy.pressRight();
        assertEquals(1, bombGuy.getY());
        assertEquals(3, bombGuy.getX());
        bombGuy.pressDown();
        bombGuy.pressRight();
        assertEquals(2, bombGuy.getY());
        assertEquals(3, bombGuy.getX());
        bombGuy.pressUp();
        bombGuy.pressRight();
        bombGuy.pressRight();
        bombGuy.pressRight();
        assertEquals(5, bombGuy.getX());
    }
    
    @Test
    public void testPressLeft() {
        assertEquals(1, bombGuy.getY());
        assertEquals(1, bombGuy.getY());
        bombGuy.pressLeft();
        assertEquals(1, bombGuy.getY());
        assertEquals(1, bombGuy.getX());
        bombGuy.pressRight();
        assertEquals(1, bombGuy.getY());
        assertEquals(2, bombGuy.getX());
        bombGuy.pressLeft();
        assertEquals(1, bombGuy.getY());
        assertEquals(1, bombGuy.getX());
        bombGuy.pressRight();
        bombGuy.pressRight();
        bombGuy.pressDown();
        bombGuy.pressDown();
        bombGuy.pressDown();
        bombGuy.pressDown();
        bombGuy.pressDown();
        bombGuy.pressDown();
        bombGuy.pressLeft();
        bombGuy.pressLeft();
        bombGuy.pressLeft();
        assertEquals(2, bombGuy.getX());
    }

    @Test
    public void testIsBombGuy() {
        assertTrue(bombGuy.isBombguy());
    }

    @Test
    public void testLives() {
        bombGuy.setLives(3);
        assertEquals(3, bombGuy.getLives());
    }

    @Test
    public void testTick() {
        for (int i = 0; i < 120; i++)
            bombGuy.tick();
    }

    //USE THE TESTTILE.TXT TO TEST BOMBGUY AGAINST ALL SPECIAL SQUARES
    @Test
    public void testCollisionWithRed() {
        //Moving to the third level where tiles can be easily checked against.
        levelcreator.incrementLv();
        levelcreator.incrementLv();
        levelcreator.tick();
        bombGuy.tick();
        bombGuy.setLives(3);
        levelcreator.tick();
        //Now move bombguy towards the red tile
        bombGuy.pressLeft();
        bombGuy.pressLeft();
        assertEquals(3, bombGuy.getLives());
        bombGuy.pressLeft();
        //Bombguy should have died
        assertEquals(2, bombGuy.getLives());
        //Since his lives have decreased, he has died.
    }

    @Test
    public void testCollisionWithYellow() {
        //Moving to the third level where tiles can be easily checked against.
        levelcreator.incrementLv();
        levelcreator.incrementLv();
        levelcreator.tick();
        bombGuy.tick();
        bombGuy.setLives(3);
        levelcreator.tick();
        //Now move bombguy towards the yellow tile
        bombGuy.pressDown();
        bombGuy.pressLeft();
        bombGuy.pressLeft();
        assertEquals(3, bombGuy.getLives());
        bombGuy.pressLeft();
        //Bombguy should have died
        assertEquals(2, bombGuy.getLives());
        //Since his lives have decreased, he has died.
    }

    @Test
    public void testCollisionWithExplosion() {
        //Moving to the third level where tiles can be easily checked against.
        levelcreator.incrementLv();
        levelcreator.incrementLv();
        levelcreator.tick();
        bombGuy.tick();
        bombGuy.setLives(3);
        levelcreator.tick();
        //Now move bombguy towards the yellow tile
        bombGuy.pressDown();
        bombGuy.pressDown();
        bombGuy.pressLeft();
        bombGuy.pressLeft();
        assertEquals(3, bombGuy.getLives());
        bombGuy.pressLeft();
        //Bombguy should have died
        assertEquals(2, bombGuy.getLives());
        //Since his lives have decreased, he has died.
    }

    @Test
    public void testCollisionWithOccupiedGoalTile() {
        //Moving to the third level where tiles can be easily checked against.
        levelcreator.incrementLv();
        levelcreator.incrementLv();
        levelcreator.tick();
        bombGuy.tick();
        bombGuy.setLives(3);
        levelcreator.tick();
        //Now move bombguy towards the yellow tile
        bombGuy.pressUp();
        bombGuy.pressUp();
        bombGuy.pressLeft();
        bombGuy.pressLeft();
        assertEquals(3, bombGuy.getLives());
        bombGuy.pressLeft();
        //Bombguy should have died
        assertEquals(2, bombGuy.getLives());
        //Since his lives have decreased, he has died.
    }

    @Test
    public void testCollisionWithGoalTile() {
        //Moving to the third level where tiles can be easily checked against.
        levelcreator.incrementLv();
        levelcreator.incrementLv();
        levelcreator.tick();
        bombGuy.tick();
        bombGuy.setLives(3);
        levelcreator.tick();
        //Now move bombguy towards the yellow tile
        bombGuy.pressUp();
        bombGuy.pressLeft();
        bombGuy.pressLeft();
        assertEquals(3, bombGuy.getLives());
        bombGuy.pressLeft();
        //Bombguy should have gone onto the goal tile
        assertEquals(3, bombGuy.getLives());
        //Level should have incremented.
        assertEquals(3, levelcreator.getLevel());
    }

    

}